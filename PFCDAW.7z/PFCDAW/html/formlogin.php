<?php
    $ruta=$_SERVER['DOCUMENT_ROOT'];
     require_once $ruta .'/PFCDAW/config.php';
?>

<html lang="es"> 
        <head>
            <title>loginpyc</title>		
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta http-equiv="X-UA-Compatible" content="ie=edge">
            <link rel="stylesheet" href="<?php echo $FOLDER_CSS?>/estilosCSS.css">  
  
</head>
    <body>
 <?php       
 /*    echo "Directori0 actual ";
     echo $_SERVER['DOCUMENT_ROOT']."<br>";
    echo dirname( __DIR__ );
     echo getcwd();   */
 ?>   
        <div class="cuadro_cabecera_login">	
			<div><img src="<?php echo FOLDER_IMG ?>/logoini_gris.jpg"></div>
                        <div><img src="<?php echo FOLDER_IMG ?>/logoini_gris.jpg"></div> 
			<div><?php echo FOLDER_IMG ?></div>
            <div> </div>
        </div> 
        <div class="ruta">
            Ruta <a href="../index.html" target="_parent">
                <img src="../ico/iconohome.png">
                </a>->Quienes somos
        </div>      
        

<!--
        <div class="ruta">
            Ruta <a href="../index.html" target="_top">Menu Inicio</a>->Login
        </div>  -->

       <form action = "" method = "GET">
       <fieldset >
            <!-- Campos de entrada del formulario -->  
            <legend><h2>Login de usuario</h2> </legend>   
            <label>Usuario.......</label>    
            <input type="text" size="10" maxlength="10" name="user" id="user" placeholder="Nombre usuario"
                autocomplete="on" required><br> 
            <label>Contraseña..</label>        
            <input type="password" size="10" maxlength="10" name="contra" id="contra" placeholder="Contraseña de usuario"
                autocomplete="on" required><br>        
            
            <p><input type="submit" name="enviar" id="enviar" value="enviar">
            <input type="reset" name="cancelar" id="cancelar" value="cancelar">
            <a href="ejem1w3bis.html" class="button" target="_parent">Salir</a>
    </fieldset> 
     </form>       
    </body>
</html>


