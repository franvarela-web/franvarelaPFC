/* Pantalla menu principal   */

var formulario;

 window.onload=function(){
    formulario = creaForm('formInicio');   // crea pantalla de inicio
    creaCabecera('H1', 'Menú principal de procesos', formulario);
  
     // ident recoge el id del campo input que se creará
    var contenido = creaInput("nombreCliente", "nombcli", "text", "Nombre de cliente", formulario, 's');
    alert("Valor " + contenido);
     // vslidar valor introducido    
  //  do { } while(!validarNombre(ident.value));
  // validarNombre(ident.value);
    
    creaCabecera('H2', 'Menú principal de procesos', formulario);   
    creaInput("Edad", "edadcli", "url", "Edad del cliente", formulario, 's');

     creaCabecera('H3', 'Menú principal de procesos', formulario);
     creaCabecera('H4', 'Menú principal de procesos', formulario);       
    
 //   document.getElementById('formInicio').innerHTML = formInicio;   
    document.body.appendChild(formulario);
 }   

