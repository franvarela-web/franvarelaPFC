<?php
/* variables globales   */
  $opccolor = 1;


/* lenguajes   */
const FOLDER_PHP = "./php";
const FOLDER_JS = "./js";
const FOLDER_HTML = "./html";


if($opccolor == 1){
    $FOLDER_CSS = "./css/css1";
} else {
   $FOLDER_CSS = "./css/css2";
}    

/* biblioteca   */
const FOLDER_LIB = "./js/lib";
const FOLDER_IMG = "./Datos/Img";
const FOLDER_ICO = "./Datos/ico";

/* formularios   */
const FOLDER_FORMUL = "./js/forms";


