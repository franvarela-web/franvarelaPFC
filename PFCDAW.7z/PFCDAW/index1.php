<?php
     require_once 'config.php';
?>

<html>
    <head>
   <title>Pieles y curtidos - Tienda online</title>		
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <meta http-equiv="X-UA-Compatible" content="ie=edge">
   <link rel="stylesheet" href="<?php echo $FOLDER_CSS?>/estilosCSS.css">
 <!--          
        <script src="<?php echo FOLDER_LIB ?>/varperlib.js"></script>        
        <script src="<?php echo FOLDER_LIB ?>/varperlib2.js"></script>  
        <script src= "<?php echo FOLDER_FORMUL ?>/formInicio.js"></script>  -->
    </head>
    <body>
        <?php
        // put your code here    <form name="formulario" id="formulario">
        ?>
    <header>
     <div class="sticky-cabecera">    

<!--	<div class="grid-container">  
           <div class="cuadro_cabeceralogo logoemp"><img id="logotipo" src="<?php echo FOLDER_IMG?>/logoini.jpg"></div>  -->
           <div class="border-box"><a href="./html/frameinicio.html"  target="frame2">"<?php echo $FOLDER_CSS?>/estilosCSS.css"</a>
           <a href="./html/frameinicio.html"  target="frame2">Nosotros</a>
           <a href="./html/frameinicio.html"  target="frame2">Productos</a>
           <a href="./html/frameinicio.html"  target="frame2">Mi compra</a></div>
<!--        <div class="cuadro_cabeceralogin loginuser"><a href="./html/formlogin.html" target="_top"><img src="./ico/login_texto2.png"></a></div>    
       </div>   -->
    </div>        
<p class="caja">
  This is some multi-column text with a 40px column gap created with the CSS
  `column-gap` property. Don't you think that's fun and exciting? I sure do!
</p>
    </header>	
    
    </body>
</html>
