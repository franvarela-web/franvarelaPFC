<?php
    $ruta=$_SERVER['DOCUMENT_ROOT'];
     require_once $ruta .'/PFCDAW/config.php';
?>

<html lang="es"> 
    <head>
        <title>Pieles y curtidos - Tienda online</title>		
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="<?php echo $FOLDER_CSS?>/estilosCSS.css">  
        <!--  <link rel="stylesheet" href="./estilosCSS.css">    -->
    </head>
    <body>
        <?php
 
         ?>
    <header>
    <div class="grid-cabecera">
        <div class="item1"><img id="logotipo" src="<?php echo FOLDER_IMG?>/logoini_gris.jpg"></div>   
  
          <nav class="item2">
                   <a href="./html/frameinicio.html"  target="frame2">Inicio</a>	
                   <a href="./html/frameinicio.html"  target="frame2">Nosotros</a>
                   <a href="./html/frameinicio.html"  target="frame2">Productos</a>
                   <a href="./html/frameinicio.html"  target="frame2">Mi compra</a>
                   <a href="./html/frameinicio.html"  target="frame2">Ayuda</a>
          </nav>
          <div class="item4">Pieles y curtidos - Tienda online</div>
           <div class="item3"><a href="<?php echo FOLDER_HTML?>/formlogin.php" target="frame2">
                        <img src="<?php echo FOLDER_IMG ?>/login_user_negrogris2.png"></a></div>    
     </div> 

    </header>
   <!--  parte central-->
     <div class="cabecera-central">
         <div id="linea1"><p>Tienda de productos de piel y cuero</div>   
         <div id="linea2"><p>Díganos cual es su idea y nosotros le ayudamos a hacerla realidad.
          Desde nuestra fábrica realizamos los productos que usted nos pueda encargar</div>        
     </div>      
    <div class="grid-central">
        <div class="item11"><img  src="<?php echo FOLDER_IMG?>/publi1150x434.jpg"></div>   
        <div class="item12"><p id="negras">NUESTRAS PIELES 
        <p>Nuestras pieles son totalmente<br> sostenibles muy versátiles para<br>
        trabajos artesanales.<br>
        <p>Dejarse seducir por nuestros<br> productos son sensaciones que<br>
        marcan y dan carisma, nos hacen<br> 
        exclusivos. </div>  
        
        <div class="item13"><img src="<?php echo FOLDER_IMG?>/pielesprod220x330.jpg"></div>   

        <div class="item14"><p id="negras">NUESTRA TIENDA <br> 
        <p>Expresa tu estilo propio, resalta lo<br>que te hace único con nuestros<br> 
        diseños exclusivos.<br> 
        <p>Cada pieza es una declaración de<br> elegancia y autenticidad,<br>
        confeccionada con el mayor de los<br>
        cuidados y el detalle.usivos.<br> 
        exclusivos. </div>   
        
       <div class="item15"><img src="<?php echo FOLDER_IMG?>/mantatien220x330.jpg"></div>  
     </div>  

 <div class="footer">
	<div id="f1">	
			<div>Autor: Fran Varela</div>
			<div>Telf: 034 630146839</div>         
			<div><a href="mailto:pantevarela@gmail.com">mail:pantevarela@gmail.com</a></div>
	</div>
	<div>	</div>
	<div id="f2">
            <div><a href="/facebook.com"><img src="<?php echo FOLDER_ICO?>/facebook.png"></a></div>
            <div><a href="/facebook.com"><img src="<?php echo FOLDER_ICO?>/twitter.png"></a></div>
            <div><a href="/facebook.com"><img src="<?php echo FOLDER_ICO?>/otro.png"></a></div>
	</div>  
</div>   
    </body>
</html>
